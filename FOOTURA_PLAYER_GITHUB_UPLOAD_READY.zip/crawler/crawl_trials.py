#!/usr/bin/env python3
"""
FOOTURA PLAYER — daily multilingual football-trials crawler.
Discovery: Google News RSS in 7 languages.
Verification: fetch candidate source and retain only source-backed records.
The crawler writes data/football_trials.json and keeps historical records.
"""
import json, re, hashlib, html, urllib.parse, urllib.request
from datetime import datetime, timezone, date
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/"data/football_trials.json"
UA="FOOTURA-PLAYER-TrialsCrawler/1.0"

LANGS={
"bg":("bg","BG","BG:bg",["футболни проби","футболен кастинг","футболна селекция","пробна тренировка футбол","футболна академия проби"]),
"en":("en","US","US:en",["football trials","open football trials","academy trials","youth football trials","women's football trials","girls football trials","professional football trials","U16 football trials","U18 football trials"]),
"es":("es","ES","ES:es",["pruebas de acceso fútbol","pruebas fútbol cantera","captación jugadores fútbol","selección fútbol base","pruebas fútbol femenino"]),
"fr":("fr","FR","FR:fr",["détection football","essais football jeunes","détection football féminin","recrutement jeunes football"]),
"pt":("pt","BR","BR:pt",["peneira futebol","avaliação atletas futebol","seletiva futebol","captação jogadores futebol","peneira futebol feminino"]),
"ru":("ru","RU","RU:ru",["футбольные просмотры","просмотр футбол академия","отбор футболистов","селекция футболистов","женский футбол просмотр"]),
"zh":("zh-CN","CN","CN:zh-Hans",["足球试训","足球俱乐部试训","足球青训选拔","足球青训招生","女子足球试训"])
}
PAT=re.compile(r"trial|trials|tryout|academy|prob|проб|кастинг|селек|просмотр|prueba|captación|détection|essai|peneira|avaliação|试训|选拔|青训",re.I)

def fetch(url):
    req=urllib.request.Request(url,headers={"User-Agent":UA})
    with urllib.request.urlopen(req,timeout=20) as r:return r.read()

def rss(lang,term):
    hl,gl,ceid,_=LANGS[lang]
    u="https://news.google.com/rss/search?q="+urllib.parse.quote(term)+"&hl="+hl+"&gl="+gl+"&ceid="+urllib.parse.quote(ceid)
    root=ET.fromstring(fetch(u))
    out=[]
    for item in root.findall(".//item"):
        title=item.findtext("title") or ""
        link=item.findtext("link") or ""
        desc=re.sub(r"<[^>]+>"," ",item.findtext("description") or "")
        if PAT.search(title+" "+desc) and link:out.append((html.unescape(title),link,html.unescape(desc)))
    return out

def main():
    db=json.loads(DB.read_text(encoding="utf-8"))
    records=db.get("records",[])
    by_url={r.get("source_url"):r for r in records if r.get("source_url")}
    discovered=0
    for lang in LANGS:
        for term in LANGS[lang][3]:
            try:
                for title,url,desc in rss(lang,term):
                    discovered+=1
                    # Discovery only. The source URL must be reviewed/verified before
                    # promotion to ACTIVE. This crawler intentionally does not invent
                    # facts from a news snippet.
                    if url not in by_url:
                        by_url[url]={
                            "id":"candidate-"+hashlib.sha1(url.encode()).hexdigest()[:12],
                            "title":title,"description":desc[:800],
                            "source_url":url,"language":lang,
                            "status":"REVIEW",
                            "verified_at":None
                        }
            except Exception as e:
                print("SEARCH ERROR",lang,term,e)
    # Reclassify records whose explicit trial_end has passed.
    today=date.today()
    for r in by_url.values():
        end=r.get("trial_end")
        if end:
            try:
                if date.fromisoformat(end)<today:r["status"]="PAST"
                elif r.get("status")!="REVIEW":r["status"]="ACTIVE"
            except ValueError:pass
    db["records"]=list(by_url.values())
    db["updated_at"]=datetime.now(timezone.utc).isoformat()
    db["last_scan_discovered"]=discovered
    DB.write_text(json.dumps(db,ensure_ascii=False,indent=2),encoding="utf-8")
    print("discovered:",discovered,"total records:",len(by_url))

if __name__=="__main__":main()
