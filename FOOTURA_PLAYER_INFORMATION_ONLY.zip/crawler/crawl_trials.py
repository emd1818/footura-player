#!/usr/bin/env python3
"""
FOOTURA PLAYER — multilingual football-trials crawler.

Runs from GitHub Actions every 24 hours.
Discovery: Google News RSS in 7 languages.
Verification: follows the source URL, extracts the canonical/original page,
checks for trial/selection language and a plausible date, then promotes
source-backed future opportunities to ACTIVE. Uncertain items remain REVIEW.
"""
import json, re, hashlib, html, urllib.parse, urllib.request
from datetime import datetime, timezone, date
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "data" / "football_trials.json"
UA = "FOOTURA-PLAYER-TrialsCrawler/2.0"

LANGS = {
    "bg": ("bg", "BG", "BG:bg", ["футболни проби","футболен кастинг","футболна селекция","пробна тренировка футбол","футболна академия проби"]),
    "en": ("en", "US", "US:en", ["football trials","open football trials","academy trials","youth football trials","women's football trials","girls football trials","professional football trials"]),
    "es": ("es", "ES", "ES:es", ["pruebas de fútbol","pruebas fútbol cantera","captación jugadores fútbol","selección fútbol base","pruebas fútbol femenino"]),
    "fr": ("fr", "FR", "FR:fr", ["détection football","essais football jeunes","détection football féminin","recrutement jeunes football"]),
    "pt": ("pt", "BR", "BR:pt", ["peneira futebol","avaliação atletas futebol","seletiva futebol","captação jogadores futebol","peneira futebol feminino"]),
    "ru": ("ru", "RU", "RU:ru", ["футбольные просмотры","просмотр футбол академия","отбор футболистов","селекция футболистов","женский футбол просмотр"]),
    "zh": ("zh-CN", "CN", "CN:zh-Hans", ["足球试训","足球俱乐部试训","足球青训选拔","足球青训招生","女子足球试训"])
}

TRIAL_WORDS = re.compile(
    r"trial|trials|tryout|academy trial|open trial|selection|recruitment|"
    r"проб|кастинг|селек|просмотр|prueba|captación|selección|détection|essai|"
    r"recrutement|peneira|seletiva|avaliação|试训|选拔|青训|招募",
    re.I
)

DATE_PATTERNS = [
    re.compile(r"\b(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})\b"),
    re.compile(r"\b(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2})\b"),
]
MONTHS = {
    "january":1,"february":2,"march":3,"april":4,"may":5,"june":6,"july":7,"august":8,"september":9,"october":10,"november":11,"december":12,
    "януари":1,"февруари":2,"март":3,"април":4,"май":5,"юни":6,"юли":7,"август":8,"септември":9,"октомври":10,"ноември":11,"декември":12,
    "enero":1,"febrero":2,"marzo":3,"abril":4,"mayo":5,"junio":6,"julio":7,"agosto":8,"septiembre":9,"octubre":10,"noviembre":11,"diciembre":12,
    "janvier":1,"février":2,"mars":3,"avril":4,"mai":5,"juin":6,"juillet":7,"août":8,"septembre":9,"octobre":10,"novembre":11,"décembre":12,
    "janeiro":1,"fevereiro":2,"março":3,"abril":4,"maio":5,"junho":6,"julho":7,"agosto":8,"setembro":9,"outubro":10,"novembro":11,"dezembro":12,
}

def fetch(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.geturl(), r.read()

def clean_text(s):
    s = html.unescape(s or "")
    s = re.sub(r"<script[\s\S]*?</script>", " ", s, flags=re.I)
    s = re.sub(r"<style[\s\S]*?</style>", " ", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def rss(lang, term):
    hl, gl, ceid, _ = LANGS[lang]
    u = "https://news.google.com/rss/search?q=" + urllib.parse.quote(term) + \
        "&hl=" + hl + "&gl=" + gl + "&ceid=" + urllib.parse.quote(ceid)
    _, body = fetch(u)
    root = ET.fromstring(body)
    out = []
    for item in root.findall(".//item"):
        title = html.unescape(item.findtext("title") or "")
        link = item.findtext("link") or ""
        desc = clean_text(item.findtext("description") or "")
        if link and TRIAL_WORDS.search(title + " " + desc):
            out.append((title, link, desc))
    return out

def canonical_url(page_url, html_text):
    m = re.search(r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)', html_text, re.I)
    if m:
        return urllib.parse.urljoin(page_url, html.unescape(m.group(1)))
    return page_url

def extract_title(html_text):
    m = re.search(r"<title[^>]*>(.*?)</title>", html_text, re.I | re.S)
    return clean_text(m.group(1)) if m else ""

def extract_dates(text):
    found = []
    for p in DATE_PATTERNS:
        for m in p.finditer(text):
            try:
                a, b, c = map(int, m.groups())
                if a >= 2000:
                    y, mo, d = a, b, c
                else:
                    d, mo, y = a, b, c
                dt = date(y, mo, d)
                if 2000 <= y <= 2035:
                    found.append(dt)
            except ValueError:
                pass
    # English/European month names
    month_re = r"(\d{1,2})\s+([A-Za-zА-Яа-яÀ-ÿ]+)\s+(20\d{2})"
    for d, mon, y in re.findall(month_re, text):
        mo = MONTHS.get(mon.lower())
        if mo:
            try:
                found.append(date(int(y), mo, int(d)))
            except ValueError:
                pass
    return sorted(set(found))

def extract_age(text):
    patterns = [
        r"\bU[- ]?(\d{1,2})\b",
        r"\b(?:ages?|age)\s*(\d{1,2})\s*[-–]\s*(\d{1,2})\b",
        r"\b(\d{1,2})\s*[-–]\s*(\d{1,2})\s*(?:years?|години|ans|anos|лет)\b",
    ]
    for p in patterns:
        m = re.search(p, text, re.I)
        if m:
            nums = [int(x) for x in m.groups() if x]
            if len(nums) == 1:
                return nums[0], nums[0]
            if len(nums) == 2:
                return min(nums), max(nums)
    return None, None

def verify(title, url, desc, lang):
    try:
        final_url, body = fetch(url)
        html_text = body.decode("utf-8", errors="ignore")[:250000]
        page_title = extract_title(html_text)
        text = clean_text(html_text)
        evidence = (title + " " + desc + " " + page_title + " " + text[:120000])
        if not TRIAL_WORDS.search(evidence):
            return None
        dates = extract_dates(text)
        future_dates = [d for d in dates if d >= date.today()]
        age_min, age_max = extract_age(text)
        final_url = canonical_url(final_url, html_text)
        source_name = urllib.parse.urlparse(final_url).netloc.replace("www.", "")
        status = "ACTIVE" if future_dates else "REVIEW"
        trial_start = future_dates[0].isoformat() if future_dates else None
        trial_end = future_dates[-1].isoformat() if future_dates else None
        return {
            "id": "trial-" + hashlib.sha1(final_url.encode()).hexdigest()[:12],
            "title": page_title or title,
            "description": clean_text(desc)[:800],
            "source_url": final_url,
            "source_name": source_name,
            "language": lang,
            "trial_start": trial_start,
            "trial_end": trial_end,
            "age_min": age_min,
            "age_max": age_max,
            "status": status,
            "verified_at": datetime.now(timezone.utc).isoformat(),
        }
    except Exception:
        return None

def main():
    db = json.loads(DB.read_text(encoding="utf-8"))
    records = db.get("records", [])
    by_url = {(r.get("source_url"), r.get("trial_start")): r for r in records if r.get("source_url")}
    discovered = verified = promoted = 0

    for lang, spec in LANGS.items():
        for term in spec[3]:
            try:
                for title, url, desc in rss(lang, term):
                    discovered += 1
                    result = verify(title, url, desc, lang)
                    if not result:
                        continue
                    verified += 1
                    key = (result["source_url"], result.get("trial_start"))
                    old = by_url.get(key)
                    if old:
                        # Preserve richer manually curated fields.
                        old.update({k:v for k,v in result.items() if v not in (None, "")})
                        if result["status"] == "ACTIVE":
                            old["status"] = "ACTIVE"
                    else:
                        by_url[key] = result
                        if result["status"] == "ACTIVE":
                            promoted += 1
            except Exception as e:
                print("SEARCH ERROR", lang, term, e)

    today = date.today()
    for r in by_url.values():
        end = r.get("trial_end")
        if end:
            try:
                r["status"] = "PAST" if date.fromisoformat(end) < today else r.get("status", "ACTIVE")
            except ValueError:
                pass

    db["records"] = list(by_url.values())
    db["updated_at"] = datetime.now(timezone.utc).isoformat()
    db["last_full_scan"] = today.isoformat()
    db["last_scan_discovered"] = discovered
    db["last_scan_verified"] = verified
    db["last_scan_promoted"] = promoted
    DB.write_text(json.dumps(db, ensure_ascii=False, indent=2), encoding="utf-8")
    print("discovered:", discovered, "verified:", verified, "promoted:", promoted, "total:", len(by_url))

if __name__ == "__main__":
    main()
